class BankAccount:
    def __init__(self, account_number, account_holder_name, initial_balance=0.0):
        self.__account_number = account_number
        self.__account_holder_name = account_holder_name
        self.__account_balance = initial_balance

    def deposit(self, amount):
        if amount > 0:
            self.__account_balance += amount
            return True
        else:
            print("Invalid deposit amount. Amount must be greater than zero.")
            return False

    def withdraw(self, amount):
        if 0 < amount <= self.__account_balance:
            self.__account_balance -= amount
            return True
        else:
            print("Invalid withdrawal amount. Insufficient balance.")
            return False

    def display_balance(self):
        print(f"Account Number: {self.__account_number}")
        print(f"Account Holder: {self.__account_holder_name}")
        print(f"Account Balance: ${self.__account_balance:.2f}")


# Testing the BankAccount class
if __name__ == "__main__":
    # Create an instance of the BankAccount class
    account = BankAccount("12345", "John Doe", 1000.0)

    # Display the initial balance
    account.display_balance()

    # Deposit $500
    account.deposit(500)
    account.display_balance()

    # Withdraw $200
    account.withdraw(200)
    account.display_balance()

    # Attempt to withdraw $1500 (insufficient balance)
    account.withdraw(1500)
